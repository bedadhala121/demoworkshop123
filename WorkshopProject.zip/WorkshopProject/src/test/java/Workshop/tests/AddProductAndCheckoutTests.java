package Workshop.tests;
import org.apache.log4j.Logger;
import org.apache.log4j.MDC;
import org.testng.Assert;
import org.testng.annotations.Test;

import Pages.CartPage;
import Pages.CheckoutPage;
import Pages.HomePage;
import Pages.LoginPage;
import base.TestBase;
import io.qameta.allure.Description;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;

public class AddProductAndCheckoutTests extends TestBase{
	
	 private final Logger logger = Logger.getLogger(AddProductAndCheckoutTests.class);
	 //LoginPage loginPage = new LoginPage(driver);
	 
	 @Description("....checking user is able to login to app with correct username and password....")
	 @Test(priority = 1)
	 public void AddproductTest() throws Exception {
		 MDC.put("testClassName", this.getClass().getSimpleName());
		 logger.info("This is a log message from loginTest");
		 
		 HomePage homePage = loginPage.doLogin(prop.getProperty("username").trim(), prop.getProperty("password").trim());
		 Assert.assertTrue(homePage.isLogoutLinkExist());
		 logger.info("user successfully logged into the application");
		 
		 //get menu items count
		 int menuItemsCount = homePage.readMenuItemsAndGetCount();
		 Assert.assertEquals(menuItemsCount,7);
		 logger.info("Total MenuItems count : " + menuItemsCount);
		 
		 //select Build your own expensive computer 
		 homePage.selectProduct("Build your own expensive computer");
		 logger.info("Selected Build your own expensive Computer Product");
		 
		 //select configuration for your own computer
		 homePage.selectConfigutation("Fast", "8GB", "400 GB", "Office Suite", "2");
		 logger.info("Successfully congigured own computer ");
		 
		 //Go to Cart Page
		 CartPage cartPage = homePage.goToCartPage();
		 logger.info("Navigated to Cart Page");
		 
		 //Select Country and Navigate to Checkout Page
		 CheckoutPage checkoutPage = cartPage.selectCountryAndCheckout("India");
		 logger.info("Selected Country India And Navigated to Checkout Page");
		 
		 //confirm order
		 checkoutPage.confirmOrder("hyderabad", "Gachibowli", "India", "502319", "9999999999");
		 logger.info("Order Placed");
		
		 //verify order details
		 String OrderId = checkoutPage.verifyOrderDetails("Your order has been successfully processed!");
		 System.out.println("Order Id : " + OrderId);
		 logger.info("Order Confirmed");
		 
		}
	 

}
