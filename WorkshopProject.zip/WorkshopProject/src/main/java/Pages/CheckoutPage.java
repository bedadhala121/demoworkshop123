package Pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import utils.ElementUtil;
import utils.JavaScriptUtil;

public class CheckoutPage {
	
	private WebDriver driver;
	private ElementUtil eleUtil;
	private JavaScriptUtil javaUtil;
	
	private By billingCity = By.id("BillingNewAddress_City");
	private By billingAddress = By.id("BillingNewAddress_Address1");
	private By billingCountry = By.id("BillingNewAddress_CountryId");
	private By billingPostalCode = By.id("BillingNewAddress_ZipPostalCode");
	private By billingPhoneNumber = By.id("BillingNewAddress_PhoneNumber");
	private String continueBtn = "(//input[@value='Continue'])";
	private By confirmOrder = By.xpath("//input[@value='Confirm']");
	private By verifyOrderMessge = By.xpath("//div[@class='title']");
	private By orderDetails = By.xpath("//ul[@class='details']");
	
	public CheckoutPage(WebDriver driver) {
		this.driver = driver;
		eleUtil = new ElementUtil(driver);
		javaUtil = new JavaScriptUtil(driver);
	}
	
	public void confirmOrder(String city, String address, String country, String postalCode, String phonemuber)
	{
		try
		{
			//select Country
			eleUtil.doSelectDropDownByVisibleText(billingCountry, country);
			
			//enter billing city
			eleUtil.getElement(billingCity, 30).sendKeys(city);
			
			//enter billing address
			eleUtil.getElement(billingAddress, 30).sendKeys(address);
			
			//enter postal code
			eleUtil.getElement(billingPostalCode, 30).sendKeys(postalCode); 
			
			//enter phone number
			eleUtil.getElement(billingPhoneNumber, 30).sendKeys(phonemuber); 
			
			//click on continue
			eleUtil.getElement(By.xpath(continueBtn), 20).click();
			
			//click on continue with same shipping address
			eleUtil.getElement(By.xpath(continueBtn+"[2]"), 20).click();
			
			//click on continue with default shipping method
			eleUtil.getElement(By.xpath(continueBtn+"[3]"), 20).click();
			
			//click on continue with default payment method COD
			eleUtil.getElement(By.xpath(continueBtn+"[4]"), 20).click();
			
			//click on continue with Payment information
			eleUtil.getElement(By.xpath(continueBtn+"[5]"), 20).click();
			
			//confirm order
			WebElement confirmorderEle = (WebElement) eleUtil.getElement(confirmOrder,30);
			javaUtil.scrollIntoView(confirmorderEle);
			javaUtil.clickElementByJS(confirmorderEle);
			//eleUtil.getElement(confirmOrder, 20).click();
			
			
		}
		catch(Exception e)
		{
			throw e;
		}
		
	}
	
	public String verifyOrderDetails(String verificationMessage)
	{
		try
		{
			//verify success message
			String pageTitle = eleUtil.getElement(verifyOrderMessge, 20).getText();
			Assert.assertEquals(pageTitle,verificationMessage);
			
			//verify order details
			String orderDetailsEle = eleUtil.getElement(orderDetails, 20).getText();
			String[] getOrderId = orderDetailsEle.split("Order number: ");
			
			return getOrderId[1];
			
		}
		catch(Exception e)
		{
			throw e;
		}
	}


}
