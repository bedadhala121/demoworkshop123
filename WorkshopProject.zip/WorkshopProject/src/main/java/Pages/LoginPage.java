package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;



import utils.ElementUtil;

import io.qameta.allure.Step;

public class LoginPage {

	private WebDriver driver;
	private ElementUtil eleUtil;

	// 1. private By locators:
	private By emailId = By.id("Email");
	private By password = By.id("Password");
	private By loginLink = By.xpath("//a[text()='Log in']");
	private By loginBtn = By.xpath("//input[@value='Log in']");


	public LoginPage(WebDriver driver) {
		this.driver = driver;
		eleUtil = new ElementUtil(driver);
	}

	public HomePage doLogin(String un, String pwd) {
		System.out.println("App creds are : " + un + ":" + pwd);
		eleUtil.waitForElementVisible(loginLink, 10).click();
		eleUtil.waitForElementVisible(emailId, 10).sendKeys(un);
		eleUtil.doSendKeys(password, pwd);
		eleUtil.doClick(loginBtn);
		return new HomePage(driver);
	}
	
	
}
