package Pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


import utils.ElementUtil;
import utils.JavaScriptUtil;

public class HomePage {
	
	private WebDriver driver;
	private ElementUtil eleUtil;
	private JavaScriptUtil javaUtil;
	
	private By listitems = By.xpath("//ul[@class='top-menu']/li");
	private By logoutLink = By.xpath("//a[text()='Log out']");
	private String selectProduct = "//a[@title='Show details for %$']";
	private By attributes = By.xpath("//div[@class='attributes']");
	private By quantiySelect = By.className("qty-input");
	private By addToCart = By.xpath("//input[@value='Add to cart']");
	private By shoppingCart = By.xpath("//a[@class='ico-cart']");
	private By goToCart = By.xpath("//input[@value='Go to cart']");
	
	public HomePage(WebDriver driver) {
		this.driver = driver;
		eleUtil = new ElementUtil(driver);
		javaUtil = new JavaScriptUtil(driver);
	}
	
	public boolean isLogoutLinkExist() {
		return eleUtil.waitForElementVisible(logoutLink, 10).isDisplayed();
	}
	
	public int readMenuItemsAndGetCount()
	{
		try
		{
			List<WebElement> menuItems = eleUtil.waitForElementsVisible(listitems, 10);
			for(WebElement ele : menuItems)
			{
				System.out.println("Menu Item : " + ele.getText());
			}
			
			System.out.println("Total Count of menu items is :" + menuItems.size());
			return menuItems.size();
		}
		catch(Exception e)
		{
			throw e;
		}
		
	}
	
	public void selectProduct(String productName) throws Exception
	{
		try
		{
			By productNameAppend = By.xpath(selectProduct.replace("%$", productName));
			WebElement prodEle = (WebElement) eleUtil.getElement(productNameAppend);
			javaUtil.scrollIntoView(prodEle);
			javaUtil.clickElementByJS(prodEle);
			
		}
		catch(Exception e)
		{
			throw e;
		}
	}

	public void selectConfigutation(String processor, String RAM, String HDD, String software, String qtyCount) throws Exception {
		try
		{
			List<WebElement> attributesEleList = driver.findElements(attributes);
			WebElement attributesEle;
			if(attributesEleList.size() > 1)
				attributesEle = attributesEleList.get(1);
			else
				attributesEle = attributesEleList.get(0);
			
				
			
			//select processor
			By processorBy = By.xpath(".//label[contains(text(),'" + processor +"')]/preceding-sibling::input");
			WebElement processorInputEle = attributesEle.findElement(processorBy);
			processorInputEle.click();
			
			//select RAM
			By ramBy = By.xpath(".//label[contains(text(),'" + RAM +"')]/preceding-sibling::input");
			WebElement ramInputEle = attributesEle.findElement(ramBy);
			ramInputEle.click();
			
			//select HDD
			By hddBy = By.xpath(".//label[contains(text(),'" + HDD +"')]/preceding-sibling::input");
			WebElement hddInputEle = attributesEle.findElement(hddBy);
			hddInputEle.click();
			
			//select Software
			By softwareBy = By.xpath(".//label[contains(text(),'" + software +"')]/preceding-sibling::input");
			WebElement softwareInputEle = attributesEle.findElement(softwareBy);
			softwareInputEle.click();
			
			//select quantity
			eleUtil.getElement(quantiySelect, 10).sendKeys(qtyCount);
			
			//Add to Cart
			eleUtil.getElement(addToCart, 10).click();
			
		}
		catch(Exception e)
		{
			throw e;
		}
		
	}
	
	public CartPage goToCartPage()
	{
		try
		{
			//mouse over on shopping cart
			eleUtil.moveToElement(shoppingCart);
			System.out.println("Mouse over on shopping Cart");
			
			//click on Go to Cart Page
			eleUtil.waitForElementPresenceWithFluentWait(20,5,goToCart).click();
			return new CartPage(driver);
			
		}
		catch(Exception e)
		{
			throw e;
		}
	}

}
