package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import utils.ElementUtil;
import utils.JavaScriptUtil;

public class CartPage {
	
	private WebDriver driver;
	private ElementUtil eleUtil;
	private JavaScriptUtil javaUtil;
	
	private By selectCountry = By.id("CountryId");
	private By checkout = By.id("checkout");
	private By termAndcondition = By.id("termsofservice");
	
	public CartPage(WebDriver driver) {
		this.driver = driver;
		eleUtil = new ElementUtil(driver);
		javaUtil = new JavaScriptUtil(driver);
	}
	
	public CheckoutPage selectCountryAndCheckout(String countryName)
	{
		try
		{
			eleUtil.doSelectDropDownByVisibleText(selectCountry, countryName);
			
			//term & condition check
			eleUtil.getElement(termAndcondition, 30).click();
			
			//checkout
			eleUtil.getElement(checkout, 30).click();
			
			return new CheckoutPage(driver);
		}
		catch(Exception e)
		{
			throw e;
		}
	}

}
