package base;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.aspectj.util.FileUtil;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;

import Pages.LoginPage;
import io.github.bonigarcia.wdm.WebDriverManager;



public class TestBase {
	public static WebDriver driver;
	public static Properties prop;
	protected LoginPage loginPage;
	public static ThreadLocal<WebDriver> tlDriver = new ThreadLocal<WebDriver>();
	
	@Parameters({ "browser", "testcasename" })
	@BeforeTest
	public void setup(String browserName, String testCaseName) {
		prop = initProp();

		if (browserName != null) {
			prop.setProperty("browser", browserName);
			prop.setProperty("testcasename", testCaseName);

		}

		driver = initialization();
		loginPage = new LoginPage(driver);

	}


	public WebDriver initialization() {

		String browser = prop.getProperty("Browser");

		if (browser.equals("Chrome")) {

			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
		}

		else {

			//System.setProperty("webdriver.gecko.driver", "C:\\My_workspace\\demoWebshop\\drivers\\geckodriver.exe");

			driver = new FirefoxDriver();

		}
		
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		driver.get(prop.getProperty("url").trim());
		return driver;

	}
	
	
	public Properties initProp() {

		prop = new Properties();
		FileInputStream ip = null;
		String envName = System.getProperty("env");

		try {
			ip = new FileInputStream("./src/test/resources/config/config.properties");
		} catch (FileNotFoundException e) {

		}

		try {
			prop.load(ip);
		} catch (IOException e) {
			e.printStackTrace();
		}

		return prop;
	}
	
	public static String getScreenshot() {
		File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		String path = System.getProperty("user.dir") + "/screenshot/" + System.currentTimeMillis() + ".png";
		File destination = new File(path);
		try {
			FileUtil.copyFile(srcFile, destination);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return path;
	}
	
	@AfterTest
	public void tearDown() {
		driver.quit();
	}

}
